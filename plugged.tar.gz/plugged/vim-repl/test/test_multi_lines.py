def train(self):
    if 1:
        2
    f(1,
            2)
    mean_acc = list()
    return 1

def f(a, b, c):
    return a + b + c

if 1:
    f(1,
            2,
                    3)
    print("hello")
