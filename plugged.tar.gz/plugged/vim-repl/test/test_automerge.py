a = "1123\
4567"
print(a)

b = 1 + 2\
        +3\
        +4
print(b)

def f(a, b):
    return a + b

b = 1 + 2\
+3\
+4\
+ f(1,
2) +\
5

print(b)
