import numpy as np

class myclass:
    def __init__(self):
        self.x = 1
        self.y = 1

x = myclass()

y: int = 1

z = {"ZYT": 1993}

z["zyt"] = 1993

# CHECKPOINT 2153462
# 2018-08-12

# CHECKPOINT 7277560
# 2018-08-12

# CP 5321993
# 2018-08-13
