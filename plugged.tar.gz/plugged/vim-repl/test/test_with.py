with open("./gcd.py") as input:
    content = input.readlines()
