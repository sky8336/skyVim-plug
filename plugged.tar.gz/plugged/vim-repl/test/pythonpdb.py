import time

for i in range(10):
    for j in range(10):
        time.sleep(1)
        print(i + j)

