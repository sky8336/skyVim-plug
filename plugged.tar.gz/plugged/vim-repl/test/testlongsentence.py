if "1".startswith("longlonglong long lon\
            test"):
    print("hello")

if "1".startswith("longlonglong long lon test"):
    print("hello")
