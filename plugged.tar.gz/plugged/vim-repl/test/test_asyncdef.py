async def test():
    print("test")

def test1(a):
    return a
