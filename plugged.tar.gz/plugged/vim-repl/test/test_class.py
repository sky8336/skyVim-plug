class A:

    def __init__(self):
        A.a = 1
        print(1)

    def fun(self):
        return

a = A()
print(a.a)


class Dictionary:
    def __init__(self):
        if os.path.exists(self.word_index_count_file):
            for line in word_index_count:
                content = line.split(" ")
            self.freq = self.freq / self.freq.sum()

    def count_word_number(self):
        content = list()
