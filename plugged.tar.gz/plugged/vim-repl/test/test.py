def f(a, b):
    print("hello")
    print("hello")
    print("hello")
    print("hello")
    print("hello")

f(range(4), range(3))

for i in [1, 2, 3]:
    print(i)
