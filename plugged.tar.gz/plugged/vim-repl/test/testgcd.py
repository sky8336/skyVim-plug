import gcd

print(gcd.gcd(12, 20))
