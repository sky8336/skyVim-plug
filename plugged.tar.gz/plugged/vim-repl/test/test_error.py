a = 1
b = aa
c = b

def func(a, b):
    return a / b

func(1, 0)

import math

math.sqrt(-1)
