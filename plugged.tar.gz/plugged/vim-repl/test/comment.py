def func(a):
    # a is a list
    s = """
    # test
    """
    return len(a)

def fung(a):
    """
    # this is a test
    """
    return len(a)
