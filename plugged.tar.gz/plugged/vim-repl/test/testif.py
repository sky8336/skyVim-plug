if 1:
    if 1:
        1
    else:
        pass
else:
    pass

def func():
    if True:
        return 1
    for i in range(3):
        return 0
