import numpy as np
a_variable = np.zeros(19)
b_variable = np.ones(10)
