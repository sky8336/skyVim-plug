print("中文测试")
