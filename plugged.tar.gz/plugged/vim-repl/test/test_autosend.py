for i in range(19):
    print(i)

if 1:
    print(2)
else:
    print(3)
